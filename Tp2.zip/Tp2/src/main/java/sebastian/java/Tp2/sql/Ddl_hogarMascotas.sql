SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

DROP DATABASE  IF EXISTS `hogarmascotas`; 

CREATE SCHEMA IF NOT EXISTS `hogarmascotas` DEFAULT CHARACTER SET utf8 ;


CREATE SCHEMA IF NOT EXISTS `hogarmascotasbd` ;
USE `hogarmascotas` ;

-- -----------------------------------------------------
-- Table `hogarmascotas`.`responsables`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hogarmascotas`.`responsables` (
  `idResponsable` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `apellido` VARCHAR(45) NOT NULL,
  `direccion` TEXT NOT NULL,
  `telefono` INT(11) NULL DEFAULT NULL,
  `ciudad` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `dni` INT(11) NOT NULL,
  PRIMARY KEY (`idResponsable`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `hogarmascotas`.`veterinarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hogarmascotas`.`veterinarios` (
  `idVeterinario` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `apellido` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `turno` ENUM('mañana', 'tarde') NOT NULL,
  `salario` DOUBLE NOT NULL,
  PRIMARY KEY (`idVeterinario`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `hogarmascotas`.`gatos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hogarmascotas`.`gatos` (
  `idGato` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `raza` VARCHAR(45) NOT NULL,
  `edad` INT(11) NOT NULL,
  `v_trivalente` ENUM('si', 'no') NOT NULL,
  `v_leucemia` ENUM('si', 'no') NOT NULL,
  `v_rabia` ENUM('si', 'no') NOT NULL,
  `esterilizado` ENUM('esterilizado', 'no esteri') NOT NULL,
  `peso` DOUBLE NOT NULL,
  `genero` ENUM('hembra', 'macho') NOT NULL,
  `f_ingreso` DATE NOT NULL,
  `idVeterinario` INT(11) NOT NULL,
  `adopcion` ENUM('adoptado', 'no adopt') NOT NULL,
  `idResponsable` INT(11) NULL DEFAULT NULL,
  `f_adopcion` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`idGato`),
  INDEX `idResponsable_idx` (`idResponsable` ASC),
  INDEX `fkVeterinario_idx` (`idVeterinario` ASC),
  CONSTRAINT `fkResponsable`
    FOREIGN KEY (`idResponsable`)
    REFERENCES `hogarmascotas`.`responsables` (`idResponsable`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fkVeterinario`
    FOREIGN KEY (`idVeterinario`)
    REFERENCES `hogarmascotas`.`veterinarios` (`idVeterinario`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `hogarmascotas`.`perros`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hogarmascotas`.`perros` (
  `idPerro` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `raza` VARCHAR(45) NOT NULL,
  `edad` INT(11) NOT NULL,
  `v_parvovirus` ENUM('si', 'no') NOT NULL,
  `v_moquillo` ENUM('si', 'no') NOT NULL,
  `v_adenovirus` ENUM('si', 'no') NOT NULL,
  `v_hepatitis` ENUM('si', 'no') NOT NULL,
  `v_rabia` ENUM('si', 'no') NOT NULL,
  `esterilizacion` ENUM('esterilizado', 'no esteri') NOT NULL,
  `peso` DOUBLE NOT NULL,
  `genero` ENUM('hembra', 'macho') NOT NULL,
  `fechaIngreso` DATE NOT NULL,
  `idVeterinario` INT(11) NOT NULL,
  `adopcion` ENUM('adoptado', 'no adopt') NOT NULL,
  `idResponsable` INT(11) NULL DEFAULT NULL,
  `fechaAdopcion` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`idPerro`),
  INDEX `idResponsable_idx` (`idResponsable` ASC),
  INDEX `idVeterinario_idx` (`idVeterinario` ASC),
  CONSTRAINT `idResponsable`
    FOREIGN KEY (`idResponsable`)
    REFERENCES `hogarmascotas`.`responsables` (`idResponsable`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `idVeterinario`
    FOREIGN KEY (`idVeterinario`)
    REFERENCES `hogarmascotas`.`veterinarios` (`idVeterinario`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

USE `hogarmascotasbd` ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
